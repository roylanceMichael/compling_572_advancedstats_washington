class VectorInstance:
	def __init__(self, id, className, features):
		self.id = id
		self.className = className
		self.features = features