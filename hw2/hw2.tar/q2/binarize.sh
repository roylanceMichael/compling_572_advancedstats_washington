#!/bin/sh
python binarization.py $1 $2