class Word:
	def __init__(self, value, count, wordType):
		self.value = value
		self.count = count
		self.wordType = wordType