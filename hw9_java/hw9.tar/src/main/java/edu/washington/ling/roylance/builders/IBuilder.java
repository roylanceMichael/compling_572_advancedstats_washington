package edu.washington.ling.roylance.builders;

public interface IBuilder<T> {
    T build();
}
